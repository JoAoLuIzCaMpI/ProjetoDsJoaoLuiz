﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmItensVenda : Form
    {
        float total = 0;
        int cont = 1;
        String coditem1;
        public frmItensVenda()
        {
            InitializeComponent();
        }

        private void CarregarCombo()
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdfarmacia;uid=root;pwd=''");
            MySqlCommand query = new MySqlCommand();
            query.Connection = conn;
            query.CommandText = "SELECT CPF, nome FROM cliente ORDER BY nome";
            conn.Open();

            MySqlDataReader dr = query.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "nome";  // o que aparece
            comboBox1.ValueMember = "CPF";      // valor interno

        }

        private void txtProduto_TextChanged(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdfarmacia;uid=root;pwd=''");
            //Instancio o SQLCommand, responsável pelas instruções SQL e
            //Passo ao SQLCommand que a conexão que ele usará é o SQLConnection
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            //No CommandText do SQLCommand, passo a instrução SQL referente a inserção de dados
            //Nos values passo os valores digitados pelo usuário através de parâmetros

            string SQL = "SELECT * FROM produto where upper(Nome) like '" + (txtProduto.Text) + "%'";
            MySqlDataAdapter da = new MySqlDataAdapter(SQL, conn);

            DataSet ds = new DataSet();
            da.Fill(ds);

            DataTable dt = new DataTable();
            dt = ds.Tables[0];
            DGV_Produtos.DataSource = dt;
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
          
            tabControl1.SelectedTab = tabPage1;
            coditem1 = txtCodVendas.Text + "." + cont;
            string[] Produto = {coditem1, txtCod.Text, txtCodVendas.Text, txtProduto.Text, txtTotal.Text, txtQuantidade.Text};
            DGV_ItensVenda.Rows.Add(Produto);
            cont = cont + 1;

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void frmItensVenda_Load(object sender, EventArgs e)
        {
            CarregarCombo();
            mskData.Text = Convert.ToString(DateTime.Now);

            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = "Select count(IdVenda)+1 from vendas";
            conn.Open();
            comando.ExecuteNonQuery();
            txtCodVendas.Text = Convert.ToString(comando.ExecuteScalar());

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtCodCliente_TextChanged(object sender, EventArgs e)
        {

        }

        private void DGV_Produtos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DGV_Produtos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCod.Text = DGV_Produtos.CurrentRow.Cells[0].Value.ToString();
            txtProduto.Text = DGV_Produtos.CurrentRow.Cells[1].Value.ToString();
            txtValorUnitario.Text = DGV_Produtos.CurrentRow.Cells[4].Value.ToString();
            
           
        }

        private void btnGravarItens_Click(object sender, EventArgs e)
        {
            total = 0;
            for (int i = 0; i < DGV_ItensVenda.RowCount - 1; i++)
            {
                total = total + Convert.ToSingle(DGV_ItensVenda[4, i].Value.ToString());
            }
            txtTotalPagar.Text = Convert.ToString(total); //Gambiarra?
            txtTotalPagar.Text = String.Format("{0:c}", Convert.ToDecimal(txtTotalPagar.Text));
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double total;

            total = Convert.ToDouble(txtValorUnitario.Text) * Convert.ToDouble(txtQuantidade.Text);
            txtTotal.Text = Convert.ToString(total);
        }

        private void btnFinalizarVenda_Click(object sender, EventArgs e)
        {
            //mskData.Text = Convert.ToString(DateTime.Now);

            //MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
           // MySqlCommand comando = new MySqlCommand();
           // comando.Connection = conn;
            //comando.CommandText = "Select count(IdVenda)+1 from vendas";
           // conn.Open();
           // comando.ExecuteNonQuery();
           // txtCodVendas.Text = Convert.ToString(comando.ExecuteScalar());
        }

        private void DGV_ItensVenda_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnTotalPagar_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdfarmacia;uid=root;pwd=''");
            conn.Open();

            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            for (int i = 0; i < DGV_ItensVenda.RowCount - 1; i++)
            {
                comando.Parameters.Clear();

                comando.CommandText =
                    "INSERT INTO itens_venda (CodItem, valorItem, Quantidade, codBarra, IdVenda) " +
                    "VALUES (@codItem, @valorItem, @Quantidade, @codBarra, @IdVenda)";

                comando.Parameters.AddWithValue("@CodItem", DGV_ItensVenda[0, i].Value);
                comando.Parameters.AddWithValue("@valorItem", DGV_ItensVenda[4, i].Value);
                comando.Parameters.AddWithValue("@Quantidade", DGV_ItensVenda[5, i].Value);
                comando.Parameters.AddWithValue("@codBarra", DGV_ItensVenda[1, i].Value);
                comando.Parameters.AddWithValue("@IdVenda", DGV_ItensVenda[2, i].Value);

                comando.ExecuteNonQuery();  // <-- SOMENTE AGORA EXECUTA e erro aqui!!
            }

            conn.Close(); // <-- FECHA DEPOIS DO LOOP


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                DataRowView row = (DataRowView)comboBox1.SelectedItem;

                string nome = row["nome"].ToString();
                string CPF = row["CPF"].ToString();

                mskCpfCliente.Text = comboBox1.SelectedValue.ToString();
            }

        }
    }
}
