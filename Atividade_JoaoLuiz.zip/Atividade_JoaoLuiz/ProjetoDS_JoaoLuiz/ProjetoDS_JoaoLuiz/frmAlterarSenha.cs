﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmAlterarSenha : Form
    {
        public frmAlterarSenha()
        {
            InitializeComponent();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;


            comando.CommandText = ("update usuario set senha = @senha where login = @login");
            comando.Parameters.AddWithValue("@login", txtLogin.Text);
            comando.Parameters.AddWithValue("@senha", txtNovaSenha.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Senha alterada com sucesso.");
        }

        private void txtLogin_Leave(object sender, EventArgs e)
        {
            String senha;
            MySqlDataReader reg = null;

            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = "select * from usuario where login = @login";
            comando.Parameters.AddWithValue("@login", txtLogin.Text);
          
            conn.Open();
            reg = comando.ExecuteReader();

            if (reg.Read())
            {
                senha = reg["senha"].ToString();
                txtNovaSenha.Text = senha;
                txtNovaSenha.UseSystemPasswordChar = false; 
                
            }

            else
            {
                MessageBox.Show("Usuário não encontrado.");
                txtLogin.Text = "";
                txtNovaSenha.Text = "";
                txtLogin.Focus();
            }
        }

        private void frmAlterarSenha_Load(object sender, EventArgs e)
        {

        }

        private void chkVerSenha_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkVerSenha_Click(object sender, EventArgs e)
        {
            if (chkVerSenha.Checked == true)
            {
                txtNovaSenha.UseSystemPasswordChar = true;
            }
            if (chkVerSenha.Checked == false)
            {
                txtNovaSenha.UseSystemPasswordChar = false;
            }
        }

        private void frmAlterarSenha_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                txtLogin.Enabled = true;
                txtNovaSenha.Enabled = true;
                txtLogin.Focus();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();
            this.Hide();
        }
    }
}
