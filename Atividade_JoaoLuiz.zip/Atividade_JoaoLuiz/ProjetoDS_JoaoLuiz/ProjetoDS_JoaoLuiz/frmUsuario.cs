﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmUsuario : Form
    {
        public frmUsuario()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
                    }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            String login;
            MySqlDataReader reg = null;

            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = "select * from usuario where login = @login and senha = @senha";
            comando.Parameters.AddWithValue("@login", txtLogin.Text);
            comando.Parameters.AddWithValue("@senha", txtSenha.Text);
            conn.Open();
            reg = comando.ExecuteReader();

            if (reg.Read())
            {
                ClassVar.login = reg["login"].ToString();
                MessageBox.Show("Usuário logado.");

                frmMenu menu = new frmMenu();
                menu.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("Usuário/Senha não encontrado.");
                txtLogin.Text = "";
                txtSenha.Text = "";
                txtLogin.Focus();
            } 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide(); 
        }
    }
}
