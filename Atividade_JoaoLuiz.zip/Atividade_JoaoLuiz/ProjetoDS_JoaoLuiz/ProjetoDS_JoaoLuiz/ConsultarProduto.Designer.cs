﻿
namespace ProjetoDS_JoaoLuiz
{
    partial class ConsultarProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtCodBarra = new System.Windows.Forms.TextBox();
            this.btnConsulta = new System.Windows.Forms.Button();
            this.btnApagar = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtDataVal = new System.Windows.Forms.TextBox();
            this.txtUso = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.txtBula = new System.Windows.Forms.TextBox();
            this.txtAlergia = new System.Windows.Forms.TextBox();
            this.txtConsulta = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.DGVConsulta = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVConsulta)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjetoDS_JoaoLuiz.Properties.Resources.CadastroProduto__1_;
            this.pictureBox1.Location = new System.Drawing.Point(-1, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1219, 802);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // txtCodBarra
            // 
            this.txtCodBarra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodBarra.Enabled = false;
            this.txtCodBarra.Location = new System.Drawing.Point(189, 268);
            this.txtCodBarra.Multiline = true;
            this.txtCodBarra.Name = "txtCodBarra";
            this.txtCodBarra.Size = new System.Drawing.Size(219, 20);
            this.txtCodBarra.TabIndex = 5;
            // 
            // btnConsulta
            // 
            this.btnConsulta.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnConsulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnConsulta.ForeColor = System.Drawing.SystemColors.Control;
            this.btnConsulta.Location = new System.Drawing.Point(706, 571);
            this.btnConsulta.Name = "btnConsulta";
            this.btnConsulta.Size = new System.Drawing.Size(193, 46);
            this.btnConsulta.TabIndex = 6;
            this.btnConsulta.Text = "CONSULTAR";
            this.btnConsulta.UseVisualStyleBackColor = false;
            this.btnConsulta.Click += new System.EventHandler(this.btnConsulta_Click);
            // 
            // btnApagar
            // 
            this.btnApagar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnApagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnApagar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnApagar.Location = new System.Drawing.Point(934, 575);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(193, 38);
            this.btnApagar.TabIndex = 7;
            this.btnApagar.Text = "APAGAR";
            this.btnApagar.UseVisualStyleBackColor = false;
            this.btnApagar.Click += new System.EventHandler(this.btnApagar_Click);
            // 
            // txtNome
            // 
            this.txtNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNome.Enabled = false;
            this.txtNome.Location = new System.Drawing.Point(527, 268);
            this.txtNome.Multiline = true;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(219, 20);
            this.txtNome.TabIndex = 8;
            // 
            // txtDataVal
            // 
            this.txtDataVal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDataVal.Enabled = false;
            this.txtDataVal.Location = new System.Drawing.Point(847, 268);
            this.txtDataVal.Multiline = true;
            this.txtDataVal.Name = "txtDataVal";
            this.txtDataVal.Size = new System.Drawing.Size(227, 20);
            this.txtDataVal.TabIndex = 9;
            // 
            // txtUso
            // 
            this.txtUso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUso.Enabled = false;
            this.txtUso.Location = new System.Drawing.Point(262, 371);
            this.txtUso.Multiline = true;
            this.txtUso.Name = "txtUso";
            this.txtUso.Size = new System.Drawing.Size(227, 20);
            this.txtUso.TabIndex = 10;
            // 
            // txtPreco
            // 
            this.txtPreco.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPreco.Enabled = false;
            this.txtPreco.Location = new System.Drawing.Point(790, 371);
            this.txtPreco.Multiline = true;
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(227, 20);
            this.txtPreco.TabIndex = 11;
            // 
            // txtBula
            // 
            this.txtBula.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBula.Enabled = false;
            this.txtBula.Location = new System.Drawing.Point(262, 497);
            this.txtBula.Multiline = true;
            this.txtBula.Name = "txtBula";
            this.txtBula.Size = new System.Drawing.Size(227, 20);
            this.txtBula.TabIndex = 12;
            // 
            // txtAlergia
            // 
            this.txtAlergia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAlergia.Enabled = false;
            this.txtAlergia.Location = new System.Drawing.Point(790, 497);
            this.txtAlergia.Multiline = true;
            this.txtAlergia.Name = "txtAlergia";
            this.txtAlergia.Size = new System.Drawing.Size(227, 20);
            this.txtAlergia.TabIndex = 13;
            // 
            // txtConsulta
            // 
            this.txtConsulta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtConsulta.Font = new System.Drawing.Font("Comic Sans MS", 18F);
            this.txtConsulta.Location = new System.Drawing.Point(178, 575);
            this.txtConsulta.Multiline = true;
            this.txtConsulta.Name = "txtConsulta";
            this.txtConsulta.Size = new System.Drawing.Size(432, 34);
            this.txtConsulta.TabIndex = 14;
            this.txtConsulta.Text = "Digite um nome para consulta";
            this.txtConsulta.TextChanged += new System.EventHandler(this.txtConsulta_TextChanged);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnSair.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSair.Location = new System.Drawing.Point(1060, 525);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(135, 30);
            this.btnSair.TabIndex = 15;
            this.btnSair.Text = "MENU";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // DGVConsulta
            // 
            this.DGVConsulta.BackgroundColor = System.Drawing.Color.DarkOliveGreen;
            this.DGVConsulta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVConsulta.Location = new System.Drawing.Point(12, 639);
            this.DGVConsulta.Name = "DGVConsulta";
            this.DGVConsulta.Size = new System.Drawing.Size(1183, 150);
            this.DGVConsulta.TabIndex = 16;
            this.DGVConsulta.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVConsulta_CellClick);
            this.DGVConsulta.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVConsulta_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(916, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "[Aperte F1 para liberar os campos]";
            // 
            // ConsultarProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1218, 801);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGVConsulta);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.txtConsulta);
            this.Controls.Add(this.txtAlergia);
            this.Controls.Add(this.txtBula);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.txtUso);
            this.Controls.Add(this.txtDataVal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.btnConsulta);
            this.Controls.Add(this.txtCodBarra);
            this.Controls.Add(this.pictureBox1);
            this.KeyPreview = true;
            this.Name = "ConsultarProduto";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ConsultarProduto_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVConsulta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtCodBarra;
        private System.Windows.Forms.Button btnConsulta;
        private System.Windows.Forms.Button btnApagar;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtDataVal;
        private System.Windows.Forms.TextBox txtUso;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.TextBox txtBula;
        private System.Windows.Forms.TextBox txtAlergia;
        private System.Windows.Forms.TextBox txtConsulta;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.DataGridView DGVConsulta;
        private System.Windows.Forms.Label label1;
    }
}