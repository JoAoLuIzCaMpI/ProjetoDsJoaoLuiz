﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            txtLogin.Enabled = false;
            txtSenha.Enabled = false;
            btnCadastro.Enabled = false; 
        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {
         
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            
            comando.CommandText = ("insert into usuario(login,senha) values (@login,@senha)");
            comando.Parameters.AddWithValue("@login", txtLogin.Text);
            comando.Parameters.AddWithValue("@senha", txtSenha.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Usuário cadastrado com sucesso.");

            frmUsuario user = new frmUsuario();
            user.Show();
            this.Hide();  

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtLogin.Enabled = true;
            txtSenha.Enabled = true;
            btnCadastro.Enabled = true;
            txtLogin.Focus(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void btnAlterarSenha_Click(object sender, EventArgs e)
        {
            frmAlterarSenha senha = new frmAlterarSenha();
            senha.Show();
            this.Hide();
        }

        private void linkAlterarSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmAlterarSenha senha = new frmAlterarSenha();
            senha.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}
