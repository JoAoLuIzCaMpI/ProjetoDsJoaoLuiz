﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmConsultarCliente : Form
    {
        public frmConsultarCliente()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;


            comando.CommandText = ("insert into usuario(CPF,nome,idade,email,alergia,doenca) values (@CPF,@nome,@idade,@email,@alergia,@doenca)");
            comando.Parameters.AddWithValue("@CPF", txtCPF.Text);
            comando.Parameters.AddWithValue("@nome", txtNome.Text);
            comando.Parameters.AddWithValue("@idade", txtIdade.Text);
            comando.Parameters.AddWithValue("@email", txtEmail.Text);
            comando.Parameters.AddWithValue("@alergia", txtAlergia.Text);
            comando.Parameters.AddWithValue("@doenca", txtDoenca.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Usuário cadastrado com sucesso.");

             //Olhar para o CPF"
        }

        private void frmConsultarCliente_Load(object sender, EventArgs e)
        {

        }
    }
}
