﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_Emerson
{
    public partial class frmServico : Form
    {
        public frmServico()
        {
            InitializeComponent();
        }

        private void frmServico_Load(object sender, EventArgs e)
        {

        }

        private void txtConsulta_TextChanged(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            String sql = "Select * from servico where upper (Id) like '%" + txtConsulta.Text + "%'";
            MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataTable dt = new DataTable();
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtNutricao.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtAvFisica.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtValServico.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtCodPersonal.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtSuplemento.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmMenu Menu = new frmMenu();
            Menu.Show();
            this.Hide();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = ("update servico set Nutricao=@Nutricao, AvaliacaoFisica=@AvaliacaoFisica, CodPersonalTrainer=@CodPersonalTrainer, Suplementos=@Suplementos, ValServico=@ValServico where Id=@Id");
            comando.Parameters.AddWithValue("@Id", txtId.Text);
            comando.Parameters.AddWithValue("@Nutricao", txtNutricao.Text);
            comando.Parameters.AddWithValue("@AvaliacaoFisica", txtAvFisica.Text);
            comando.Parameters.AddWithValue("@CodPersonalTrainer", txtCodPersonal.Text);
            comando.Parameters.AddWithValue("@ValServico", txtValServico.Text);
            comando.Parameters.AddWithValue("@Suplementos", txtSuplemento.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Servico alterado com sucesso");
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja excluir esse cadastro?", "Exculusão de dados", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
                MySqlCommand comando = new MySqlCommand();
                comando.Connection = conn;
                comando.CommandText = ("Delete from servico where Id=@Id");
                comando.Parameters.AddWithValue("@Id", txtId.Text);
                conn.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Cadastro Excluido com sucesso");

                txtId.Text = "";
                txtAvFisica.Text = "";
                txtValServico.Text = "";
                txtCodPersonal.Text = "";
                txtSuplemento.Text = "";
                txtNutricao.Text = "";
            }

        }

        private void frmServico_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                txtSuplemento.Enabled = true;
                txtNutricao.Enabled = true;
                txtCodPersonal.Enabled = true;
                txtValServico.Enabled = true;
                txtAvFisica.Enabled = true;
            }
        }

        private void txtCodMaq_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAvFisica_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
