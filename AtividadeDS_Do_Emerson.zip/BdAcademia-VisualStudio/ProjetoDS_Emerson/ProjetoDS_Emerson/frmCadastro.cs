﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_Emerson
{
    public partial class frmCadastro : Form
    {
        public frmCadastro()
        {
            InitializeComponent();
        }

     

        private void btnCadastro_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;


            comando.CommandText = ("insert into usuario(login,senha) values (@login,@senha)");
            comando.Parameters.AddWithValue("@login", txtLg.Text);
            comando.Parameters.AddWithValue("@senha", txtPwd.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Usuário cadastrado com sucesso.");

            frmLogin user = new frmLogin();
            user.Show();
            this.Hide();
        }

        private void btnMn_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void txtPwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLg_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
