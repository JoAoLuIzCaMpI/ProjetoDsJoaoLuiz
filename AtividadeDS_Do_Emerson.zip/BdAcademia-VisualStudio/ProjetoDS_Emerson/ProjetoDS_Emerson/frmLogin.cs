﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_Emerson
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            txtLg.Enabled = false;
            txtPwd.Enabled = false;
            btnLogin.Enabled = false;
        }

        

        private void BtnMenu_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide(); 
        }

        private void btnNv_Click(object sender, EventArgs e)
        {
            frmCadastro User = new frmCadastro();
            User.Show();
            this.Hide();
        }

        private void btnTrocaSenha_Click(object sender, EventArgs e)
        {
            frmTrocaSenha TrocaSenha = new frmTrocaSenha();
            TrocaSenha.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            String login;
            MySqlDataReader reg = null;

            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = "select * from usuario where login = @login and senha = @senha";
            comando.Parameters.AddWithValue("@login", txtLg.Text);
            comando.Parameters.AddWithValue("@senha", txtPwd.Text);
            conn.Open();
            reg = comando.ExecuteReader();

            if (reg.Read())
            {
                ClassVar.Login = reg["login"].ToString();
                MessageBox.Show("Usuário logado.");

                frmMenu menu = new frmMenu();
                menu.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("Usuário/Senha não encontrado.");
                txtLg.Text = "";
                txtPwd.Text = "";
                txtLg.Focus();
            }
        }

        private void txtLg_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
