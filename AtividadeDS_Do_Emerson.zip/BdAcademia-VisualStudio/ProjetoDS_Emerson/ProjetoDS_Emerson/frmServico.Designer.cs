﻿
namespace ProjetoDS_Emerson
{
    partial class frmServico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtNutricao = new System.Windows.Forms.TextBox();
            this.txtAvFisica = new System.Windows.Forms.TextBox();
            this.txtCodPersonal = new System.Windows.Forms.TextBox();
            this.txtValServico = new System.Windows.Forms.TextBox();
            this.txtSuplemento = new System.Windows.Forms.TextBox();
            this.txtConsulta = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.btnApagar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtId
            // 
            this.txtId.Enabled = false;
            this.txtId.Location = new System.Drawing.Point(133, 264);
            this.txtId.Multiline = true;
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(237, 44);
            this.txtId.TabIndex = 10;
            this.txtId.TextChanged += new System.EventHandler(this.txtId_TextChanged);
            // 
            // txtNutricao
            // 
            this.txtNutricao.Enabled = false;
            this.txtNutricao.Location = new System.Drawing.Point(133, 384);
            this.txtNutricao.Multiline = true;
            this.txtNutricao.Name = "txtNutricao";
            this.txtNutricao.Size = new System.Drawing.Size(237, 44);
            this.txtNutricao.TabIndex = 11;
            // 
            // txtAvFisica
            // 
            this.txtAvFisica.Enabled = false;
            this.txtAvFisica.Location = new System.Drawing.Point(143, 495);
            this.txtAvFisica.Multiline = true;
            this.txtAvFisica.Name = "txtAvFisica";
            this.txtAvFisica.Size = new System.Drawing.Size(237, 44);
            this.txtAvFisica.TabIndex = 12;
            this.txtAvFisica.TextChanged += new System.EventHandler(this.txtAvFisica_TextChanged);
            // 
            // txtCodPersonal
            // 
            this.txtCodPersonal.Enabled = false;
            this.txtCodPersonal.Location = new System.Drawing.Point(864, 264);
            this.txtCodPersonal.Multiline = true;
            this.txtCodPersonal.Name = "txtCodPersonal";
            this.txtCodPersonal.Size = new System.Drawing.Size(237, 44);
            this.txtCodPersonal.TabIndex = 13;
            // 
            // txtValServico
            // 
            this.txtValServico.Enabled = false;
            this.txtValServico.Location = new System.Drawing.Point(864, 384);
            this.txtValServico.Multiline = true;
            this.txtValServico.Name = "txtValServico";
            this.txtValServico.Size = new System.Drawing.Size(237, 44);
            this.txtValServico.TabIndex = 14;
            this.txtValServico.TextChanged += new System.EventHandler(this.txtCodMaq_TextChanged);
            // 
            // txtSuplemento
            // 
            this.txtSuplemento.Enabled = false;
            this.txtSuplemento.Location = new System.Drawing.Point(852, 495);
            this.txtSuplemento.Multiline = true;
            this.txtSuplemento.Name = "txtSuplemento";
            this.txtSuplemento.Size = new System.Drawing.Size(237, 44);
            this.txtSuplemento.TabIndex = 15;
            // 
            // txtConsulta
            // 
            this.txtConsulta.Location = new System.Drawing.Point(621, 592);
            this.txtConsulta.Multiline = true;
            this.txtConsulta.Name = "txtConsulta";
            this.txtConsulta.Size = new System.Drawing.Size(278, 51);
            this.txtConsulta.TabIndex = 16;
            this.txtConsulta.TextChanged += new System.EventHandler(this.txtConsulta_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjetoDS_Emerson.Properties.Resources.Simple_Lined_Black_Login_Page_Wireframe_Website_UI_Prototype3;
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1281, 806);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 651);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1256, 135);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.Location = new System.Drawing.Point(1119, 592);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(131, 43);
            this.btnMenu.TabIndex = 19;
            this.btnMenu.Text = "Menu";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnConsultar
            // 
            this.btnConsultar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnConsultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultar.Location = new System.Drawing.Point(958, 592);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(131, 43);
            this.btnConsultar.TabIndex = 20;
            this.btnConsultar.Text = "Alterar";
            this.btnConsultar.UseVisualStyleBackColor = false;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // btnApagar
            // 
            this.btnApagar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnApagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApagar.Location = new System.Drawing.Point(95, 592);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(131, 43);
            this.btnApagar.TabIndex = 21;
            this.btnApagar.Text = "Apagar";
            this.btnApagar.UseVisualStyleBackColor = false;
            this.btnApagar.Click += new System.EventHandler(this.btnApagar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(92, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 16);
            this.label1.TabIndex = 23;
            this.label1.Text = "[F1] Para habilitar campos para alteração";
            // 
            // frmServico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 798);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtConsulta);
            this.Controls.Add(this.txtSuplemento);
            this.Controls.Add(this.txtValServico);
            this.Controls.Add(this.txtCodPersonal);
            this.Controls.Add(this.txtAvFisica);
            this.Controls.Add(this.txtNutricao);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.pictureBox1);
            this.KeyPreview = true;
            this.Name = "frmServico";
            this.Text = "frmServico";
            this.Load += new System.EventHandler(this.frmServico_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmServico_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtNutricao;
        private System.Windows.Forms.TextBox txtAvFisica;
        private System.Windows.Forms.TextBox txtCodPersonal;
        private System.Windows.Forms.TextBox txtValServico;
        private System.Windows.Forms.TextBox txtSuplemento;
        private System.Windows.Forms.TextBox txtConsulta;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Button btnApagar;
        private System.Windows.Forms.Label label1;
    }
}