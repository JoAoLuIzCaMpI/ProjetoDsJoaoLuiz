﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace ProjetoDS_Emerson
{
    public partial class frmServico2 : Form
    {
        public frmServico2()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = ("insert into servico (Id,Nutricao,AvaliacaoFisica,CodPersonalTrainer,ValServico,Suplementos)values(@Id,@Nutricao,@AvaliacaoFisica,@CodPersonalTrainer,@ValServico,@Suplementos)");
            comando.Parameters.AddWithValue("@Id", txtId.Text);
            comando.Parameters.AddWithValue("@Nutricao", txtNutricao.Text);
            comando.Parameters.AddWithValue("@AvaliacaoFisica", txtAvFisica.Text);
            comando.Parameters.AddWithValue("@CodPersonalTrainer", txtCodPersonal.Text);
            comando.Parameters.AddWithValue("@ValServico", txtValServico.Text);
            comando.Parameters.AddWithValue("@Suplementos", txtSuple.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Servico cadastrado com sucesso");


        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtNutricao.Text = "";
            txtSuple.Text = "";
            txtCodPersonal.Text = "";
            txtValServico.Text = "";
            txtAvFisica.Text = "";

        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {

            MySqlDataReader reg = null;

            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = "select * from servico where id = @id, nutricao = @nutricao, avfisica = @avfisica, codpersonal = @codpersonal, ValServico = @ValServico, suplemento = @suplemento";
            comando.Parameters.AddWithValue("@id", txtId.Text);
            comando.Parameters.AddWithValue("@nutricao", txtNutricao.Text);
            comando.Parameters.AddWithValue("@avfisica", txtAvFisica.Text);
            comando.Parameters.AddWithValue("@codpersonal", txtCodPersonal.Text);
            comando.Parameters.AddWithValue("@ValServico", txtValServico.Text);
            comando.Parameters.AddWithValue("@suplemento", txtSuple.Text);
            conn.Open();
            reg = comando.ExecuteReader();
        
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmServico servico = new frmServico();
            servico.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void txtAvFisica_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNutricao_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCodMaqui_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
