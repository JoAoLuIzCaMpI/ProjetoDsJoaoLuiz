﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_Emerson
{
    public partial class frmItensServico : Form
    {
        float total = 0;
        int cont = 1;
        String CodItem1;

        public frmItensServico()
        {
            InitializeComponent();
        }

        private void CarregarCombo()
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bd_academia;uid=root;pwd=''");
            MySqlCommand query = new MySqlCommand();
            query.Connection = conn;
            query.CommandText = "SELECT CPF, Nome FROM cliente ORDER BY Nome";
            conn.Open();

            MySqlDataReader dr = query.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Nome";  // o que aparece
            comboBox1.ValueMember = "CPF";      // valor interno

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bd_academia;uid=root;pwd=''");

            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            string SQL = "SELECT * FROM servico where upper(Nutricao) like '" + (txtServico.Text) + "%'";
            MySqlDataAdapter da = new MySqlDataAdapter(SQL, conn);

            DataSet ds = new DataSet();
            da.Fill(ds);

            DataTable dt = new DataTable();
            dt = ds.Tables[0];
            DGV_Produto.DataSource = dt;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
            CodItem1 = txtNumServico.Text + "." + cont;
            string[] servico = {CodItem1, txtCodigo.Text, txtNumServico.Text, txtTotal.Text, txtQuant.Text, txtServico.Text};
            dgv_Vendas.Rows.Add(servico);
            cont = cont + 1;


        }

        private void frmItensServico_Load(object sender, EventArgs e)
        {
            CarregarCombo();
            mskData.Text = Convert.ToString(DateTime.Now);
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = ("Select count(Id)+1 from servico");
            conn.Open();
            comando.ExecuteNonQuery();
            txtNumServico.Text = Convert.ToString(comando.ExecuteScalar());

        }

        private void txtCodigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           

        }

        private void btnNovaVenda_Click(object sender, EventArgs e)
        {
            mskData.Text = Convert.ToString(DateTime.Now);
            //Instancio o SQLConnection, passando como parametro a string de conexão ao banco
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bd_academia;uid=root;pwd=''");

            //Instancio o SQLCommand, responsavel pelas isntruçoes SQL e
            // passo ao SQLCommand que a conexão que ele usará é o SqlConnection
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = "select count(Id) + 1 from servico";
            conn.Open();
            comando.ExecuteNonQuery();
            txtNumServico.Text = Convert.ToString(comando.ExecuteScalar());

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double total;

            total = Convert.ToDouble(txtQuant.Text) * Convert.ToDouble(txtValUni.Text);
            txtTotal.Text = Convert.ToString(total);

        }

        private void btnTotalPagar_Click(object sender, EventArgs e)
        {
            decimal total = 0;

            foreach (DataGridViewRow row in dgv_Vendas.Rows)
            {
                // Verifica se as células não são nulas
                if (row.Cells["Valor_Item"].Value != null && row.Cells["Quantidade"].Value != null)
                {
                    decimal valor = Convert.ToDecimal(row.Cells["Valor_Item"].Value);
                    decimal qtd = Convert.ToDecimal(row.Cells["Quantidade"].Value);

                    total += valor * qtd;
                }
            }

            txtValServ.Text = total.ToString("N2");
        }

        private void btnGravarItem_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bd_academia;uid=root;pwd=''");
            conn.Open();

            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            for (int i = 0; i < dgv_Vendas.RowCount - 1; i++)
            {
                comando.Parameters.Clear();

                comando.CommandText =
                    "INSERT INTO itens_venda (Cod_Item, IdServico, Id_Vendas, Valor_Item, Quantidade) " + "VALUES (@Cod_Item, @IdServico, @Id_Vendas, @Valor_Item, @Quantidade)";

                comando.Parameters.AddWithValue("@Cod_Item", dgv_Vendas[0, i].Value);//Id_Venda
                comando.Parameters.AddWithValue("@Valor_Item", dgv_Vendas[1, i].Value);//Data
                comando.Parameters.AddWithValue("@Quantidade", dgv_Vendas[2, i].Value);//Valor
                comando.Parameters.AddWithValue("@IdServico", dgv_Vendas[3, i].Value);//CPF_Cliente
                comando.Parameters.AddWithValue("@Id_Vendas", dgv_Vendas[4, i].Value);

                comando.ExecuteNonQuery();  // <-- SOMENTE AGORA EXECUTA
            }

            conn.Close(); // <-- FECHA DEPOIS DO LOOP

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bd_academia;uid=root;pwd=''");
            MySqlCommand query = new MySqlCommand();
            query.Connection = conn;
            query.CommandText = "SELECT CPF, Nome FROM Cliente ORDER BY Nome";
            conn.Open();

            MySqlDataReader dr = query.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Nome";  // o que aparece
            comboBox1.ValueMember = "CPF";      // valor interno
        }

        private void comboBox1_SelectedIndexChanged_2(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                DataRowView row = (DataRowView)comboBox1.SelectedItem;

                string Nome = row["Nome"].ToString();
                string CPF = row["CPF"].ToString();

                txtCodCli.Text = comboBox1.SelectedValue.ToString();
            }

        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void DGV_Produto_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Produto

            txtCodigo.Text = DGV_Produto.CurrentRow.Cells[0].Value.ToString();
            txtServico.Text = DGV_Produto.CurrentRow.Cells[1].Value.ToString();
            txtValUni.Text = DGV_Produto.CurrentRow.Cells[4].Value.ToString();
        }

        private void txtValServ_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
