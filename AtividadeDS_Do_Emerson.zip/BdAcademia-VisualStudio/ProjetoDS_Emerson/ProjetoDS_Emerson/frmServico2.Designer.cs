﻿
namespace ProjetoDS_Emerson
{
    partial class frmServico2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.btnApagar = new System.Windows.Forms.Button();
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtNutricao = new System.Windows.Forms.TextBox();
            this.txtAvFisica = new System.Windows.Forms.TextBox();
            this.txtCodPersonal = new System.Windows.Forms.TextBox();
            this.txtValServico = new System.Windows.Forms.TextBox();
            this.txtSuple = new System.Windows.Forms.TextBox();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjetoDS_Emerson.Properties.Resources.Simple_Lined_Black_Login_Page_Wireframe_Website_UI_Prototype2;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1281, 784);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrar.Location = new System.Drawing.Point(445, 692);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(161, 53);
            this.btnCadastrar.TabIndex = 1;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = false;
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // btnApagar
            // 
            this.btnApagar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnApagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApagar.Location = new System.Drawing.Point(206, 692);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(161, 53);
            this.btnApagar.TabIndex = 2;
            this.btnApagar.Text = "Apagar";
            this.btnApagar.UseVisualStyleBackColor = false;
            this.btnApagar.Click += new System.EventHandler(this.btnApagar_Click);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(95, 235);
            this.txtId.Multiline = true;
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(237, 44);
            this.txtId.TabIndex = 4;
            this.txtId.TextChanged += new System.EventHandler(this.txtId_TextChanged);
            // 
            // txtNutricao
            // 
            this.txtNutricao.Location = new System.Drawing.Point(95, 386);
            this.txtNutricao.Multiline = true;
            this.txtNutricao.Name = "txtNutricao";
            this.txtNutricao.Size = new System.Drawing.Size(237, 44);
            this.txtNutricao.TabIndex = 5;
            this.txtNutricao.TextChanged += new System.EventHandler(this.txtNutricao_TextChanged);
            // 
            // txtAvFisica
            // 
            this.txtAvFisica.Location = new System.Drawing.Point(95, 537);
            this.txtAvFisica.Multiline = true;
            this.txtAvFisica.Name = "txtAvFisica";
            this.txtAvFisica.Size = new System.Drawing.Size(237, 44);
            this.txtAvFisica.TabIndex = 6;
            this.txtAvFisica.TextChanged += new System.EventHandler(this.txtAvFisica_TextChanged);
            // 
            // txtCodPersonal
            // 
            this.txtCodPersonal.Location = new System.Drawing.Point(941, 235);
            this.txtCodPersonal.Multiline = true;
            this.txtCodPersonal.Name = "txtCodPersonal";
            this.txtCodPersonal.Size = new System.Drawing.Size(237, 44);
            this.txtCodPersonal.TabIndex = 7;
            // 
            // txtValServico
            // 
            this.txtValServico.Location = new System.Drawing.Point(941, 386);
            this.txtValServico.Multiline = true;
            this.txtValServico.Name = "txtValServico";
            this.txtValServico.Size = new System.Drawing.Size(237, 44);
            this.txtValServico.TabIndex = 8;
            this.txtValServico.TextChanged += new System.EventHandler(this.txtCodMaqui_TextChanged);
            // 
            // txtSuple
            // 
            this.txtSuple.Location = new System.Drawing.Point(941, 537);
            this.txtSuple.Multiline = true;
            this.txtSuple.Name = "txtSuple";
            this.txtSuple.Size = new System.Drawing.Size(237, 44);
            this.txtSuple.TabIndex = 9;
            // 
            // btnConsultar
            // 
            this.btnConsultar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnConsultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultar.Location = new System.Drawing.Point(687, 692);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(148, 53);
            this.btnConsultar.TabIndex = 10;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = false;
            this.btnConsultar.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.Location = new System.Drawing.Point(911, 692);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(153, 53);
            this.btnMenu.TabIndex = 11;
            this.btnMenu.Text = "Menu";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(922, 337);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 37);
            this.label1.TabIndex = 12;
            this.label1.Text = "Valor do Serviço";
            // 
            // frmServico2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 779);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.txtSuple);
            this.Controls.Add(this.txtValServico);
            this.Controls.Add(this.txtCodPersonal);
            this.Controls.Add(this.txtAvFisica);
            this.Controls.Add(this.txtNutricao);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.btnCadastrar);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmServico2";
            this.Text = "frmServico2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Button btnApagar;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtNutricao;
        private System.Windows.Forms.TextBox txtAvFisica;
        private System.Windows.Forms.TextBox txtCodPersonal;
        private System.Windows.Forms.TextBox txtValServico;
        private System.Windows.Forms.TextBox txtSuple;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Label label1;
    }
}