﻿
namespace ProjetoDS_Emerson
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtLg = new System.Windows.Forms.TextBox();
            this.txtPwd = new System.Windows.Forms.TextBox();
            this.BtnMenu = new System.Windows.Forms.Button();
            this.btnNv = new System.Windows.Forms.Button();
            this.btnTrocaSenha = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjetoDS_Emerson.Properties.Resources.Simple_Lined_Black_Login_Page_Wireframe_Website_UI_Prototype__1_;
            this.pictureBox2.Location = new System.Drawing.Point(0, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1255, 764);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnLogin.Location = new System.Drawing.Point(555, 569);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(170, 45);
            this.btnLogin.TabIndex = 1;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtLg
            // 
            this.txtLg.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtLg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLg.Location = new System.Drawing.Point(529, 375);
            this.txtLg.Multiline = true;
            this.txtLg.Name = "txtLg";
            this.txtLg.Size = new System.Drawing.Size(234, 43);
            this.txtLg.TabIndex = 2;
            this.txtLg.TextChanged += new System.EventHandler(this.txtLg_TextChanged);
            // 
            // txtPwd
            // 
            this.txtPwd.AcceptsReturn = true;
            this.txtPwd.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPwd.Location = new System.Drawing.Point(529, 487);
            this.txtPwd.Multiline = true;
            this.txtPwd.Name = "txtPwd";
            this.txtPwd.PasswordChar = '*';
            this.txtPwd.Size = new System.Drawing.Size(234, 43);
            this.txtPwd.TabIndex = 3;
            // 
            // BtnMenu
            // 
            this.BtnMenu.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnMenu.Location = new System.Drawing.Point(555, 640);
            this.BtnMenu.Name = "BtnMenu";
            this.BtnMenu.Size = new System.Drawing.Size(170, 46);
            this.BtnMenu.TabIndex = 4;
            this.BtnMenu.Text = "Menu";
            this.BtnMenu.UseVisualStyleBackColor = false;
            this.BtnMenu.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // btnNv
            // 
            this.btnNv.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNv.Location = new System.Drawing.Point(364, 607);
            this.btnNv.Name = "btnNv";
            this.btnNv.Size = new System.Drawing.Size(170, 45);
            this.btnNv.TabIndex = 5;
            this.btnNv.Text = "Cadastro";
            this.btnNv.UseVisualStyleBackColor = false;
            this.btnNv.Click += new System.EventHandler(this.btnNv_Click);
            // 
            // btnTrocaSenha
            // 
            this.btnTrocaSenha.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnTrocaSenha.Location = new System.Drawing.Point(746, 607);
            this.btnTrocaSenha.Name = "btnTrocaSenha";
            this.btnTrocaSenha.Size = new System.Drawing.Size(170, 45);
            this.btnTrocaSenha.TabIndex = 6;
            this.btnTrocaSenha.Text = "Alterar Senha";
            this.btnTrocaSenha.UseVisualStyleBackColor = false;
            this.btnTrocaSenha.Click += new System.EventHandler(this.btnTrocaSenha_Click);
            // 
            // frmLogin
            // 
            this.ClientSize = new System.Drawing.Size(1350, 761);
            this.Controls.Add(this.btnTrocaSenha);
            this.Controls.Add(this.btnNv);
            this.Controls.Add(this.BtnMenu);
            this.Controls.Add(this.txtPwd);
            this.Controls.Add(this.txtLg);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.pictureBox2);
            this.Name = "frmLogin";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnLogar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox txtLg;
        private System.Windows.Forms.TextBox txtPwd;
        private System.Windows.Forms.Button BtnMenu;
        private System.Windows.Forms.Button btnNv;
        private System.Windows.Forms.Button btnTrocaSenha;
    }
}