﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_Emerson
{
    public partial class frmCliente : Form
    {
        public frmCliente()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = ("insert into cliente (CPF,Nome,Email,Telefone,Idade,Altura,Peso)values(@CPF,@Nome,@Email,@Telefone,@Idade,@Altura,@Peso)");
            comando.Parameters.AddWithValue("@Cpf", txtCpf.Text);
            comando.Parameters.AddWithValue("@Nome", txtNome.Text);
            comando.Parameters.AddWithValue("@Email", txtEmail.Text);
            comando.Parameters.AddWithValue("@Telefone", txtTelefone.Text);
            comando.Parameters.AddWithValue("@Idade", txtIdade.Text);
            comando.Parameters.AddWithValue("@Altura", txtAltura.Text);
            comando.Parameters.AddWithValue("@Peso", txtPeso.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Cliente cadastrado com sucesso");
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCpf_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja excluir esse cadastro?", "Exculusão de dados", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                MySqlConnection conn = new MySqlConnection("server=localhost; database=bd_academia; uid=root; pwd=''");
                MySqlCommand comando = new MySqlCommand();
                comando.Connection = conn;
                comando.CommandText = ("Delete from servico where Id=@Id");
                comando.Parameters.AddWithValue("@Id", txtCpf.Text);
                conn.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Cadastro Excluido com sucesso");

                txtCpf.Text = "";
                txtEmail.Text = "";
                txtAltura.Text = "";
                txtPeso.Text = "";
                txtNome.Text = "";
                txtTelefone.Text = "";
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            txtCpf.Text = "";
            txtAltura.Text = "";
            txtEmail.Text = "";
            txtIdade.Text = "";
            txtNome.Text = "";
            txtPeso.Text = "";
            txtTelefone.Text = "";
        }
    }
}
