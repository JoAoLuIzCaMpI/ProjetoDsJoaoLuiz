﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoDS_Emerson
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            frmCadastro usuario = new frmCadastro();
            usuario.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void frmMenu_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "[" + DateTime.Now.ToShortDateString() + "]";
            toolStripStatusLabel2.Text = "[" + DateTime.Now.ToShortTimeString() + "]";
            toolStripStatusLabel3.Text = "[" + "Usuário Logado: " + ClassVar.Login + "]";
        }

        private void btnSenha_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAltSenha_Click(object sender, EventArgs e)
        {
            frmTrocaSenha trocaSenha= new frmTrocaSenha();
            trocaSenha.Show();
            this.Hide();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            frmServico2 servico2 = new frmServico2();
            servico2.Show();
            this.Hide();
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            frmServico servico = new frmServico();
            servico.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmItensServico itensservico = new frmItensServico();
            itensservico.Show();
            this.Hide();
        }

        private void frmMenu_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                frmCliente cliente = new frmCliente();
                cliente.Show();
                this.Hide();
            }
        }
    }
}
